<?php

header("location: includes/login/landing.php");  
